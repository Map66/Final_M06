package com.example.connect_4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class Help : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)
    }

    fun About(view: View){
        val txt : TextView = findViewById(R.id.Content)
        txt.text = "This is Connect 4. A game where the object is to match up four of your tokens before" +
                " your opponent does. A piece can only be played on the lowest row of any column. Go back to the" +
                " main screen and press Open Game to play."

    }

    fun Play(view: View){
        val txt : TextView = findViewById(R.id.Content)
        txt.text = "When it is your turn press which column you want to play and the system will place your" +
                " token at the bottom row. Continue placing pieces in an attempt to connect 4 while also" +
                " stopping your opponent from doing the same."
    }

    fun go2secondActivity(view : View) {
        var intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}