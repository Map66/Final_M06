package com.example.connect_4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun go2secondActivity(view : View) {
        var intent = Intent(this,Board::class.java)
        startActivity(intent)
    }
    fun optionBtn(view : View){
        var intent = Intent(this,Setting::class.java)
        startActivity(intent)
    }
    fun helpBtn(view : View){
        var intent = Intent(this,Help::class.java)
        startActivity(intent)
    }

}