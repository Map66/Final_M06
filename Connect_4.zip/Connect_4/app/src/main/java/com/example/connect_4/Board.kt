package com.example.connect_4

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.get

class Board : AppCompatActivity() {

    var board = Array(7) {Array (6) {0}}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_board)
    }
    fun go2secondActivity(view : View) {
        var intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }

    fun btn1(view : View) { drop(0) }

    fun btn2(view : View) { drop(1) }

    fun btn3(view : View) { drop(2) }

    fun btn4(view : View) { drop(3) }

    fun btn5(view : View) { drop(4) }

    fun btn6(view : View) { drop(5) }

    fun btn7(view : View) { drop(6) }

    private fun drop(Num : Int) {
        Log.d("Num", Num.toString())
        addToArray(Num)
        placePiece(Num)
        computerPlay()

    }

    private fun addToArray (Num : Int) {
        for (index in 0..5) {
            if (board[Num][index] == 0) {
                board[Num][index] = 0
                break
            }
        }
    }

    private fun placePiece(Num : Int) {
        var lay : LinearLayout = findLayout(Num)
        Log.d("color", lay.background.toString())
        val text : TextView = lay[1] as TextView
        text.text = " Y"
    }



    @SuppressLint("WrongViewCast")
    private fun findLayout(Num : Int): LinearLayout {
        when (Num){
            0-> return findViewById<LinearLayout>(R.id.linearLayout1)
            1-> return findViewById<LinearLayout>(R.id.linearLayout2)
            2-> return findViewById<LinearLayout>(R.id.linearLayout3)
            3-> return findViewById<LinearLayout>(R.id.linearLayout4)
            4-> return findViewById<LinearLayout>(R.id.linearLayout5)
            5-> return findViewById<LinearLayout>(R.id.linearLayout6)
            else-> return findViewById<LinearLayout>(R.id.linearLayout7)
        }
    }

    private fun computerPlay() {

    }

    private fun checkPiece() {

    }

}